pace-jupyter-notebook -q coc-ice-gpu -l nodes=1:ppn=24:gpus=1,walltime=02:00:00
