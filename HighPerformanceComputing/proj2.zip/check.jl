
module Check
using MPI
export issorted

function issorted(comm::MPI.Comm, array::Vector{T})::Bool where T
    # comm: MPI Communicator
    # array: distributed, holds the values belonging to this rank

    #MPI.Init()
    rank = MPI.Comm_rank(comm)
    size = MPI.Comm_size(comm)

    # - Use Base.issorted() to determine if it is sorted locally

    # - If rank < size-1, send the last value of the array to rank+1

    # - If 0 < rank, receive that value.

    # - If the last value from rank-1 is <= the first value of the local portion of the array,
    #   and the array is sorted locally, then this rank thinks that the array is sorted

    # - Use MPI.Allreduce! with logical and (MPI.LAND) to see if _every_ process
    #   thinks the array is sorted

    # - If so, return true, otherwise re turn false

    # Determining if it is sorted:
    sorted = [Base.issorted(array)]
    if rank<size-1
        dest = rank+1
        src = rank-1
        lastVal = array[end]
        recvVal = Array{Float64}(undef,1)
        #Use MPI.Isend to avoid deadlock
        #println("$rank: Sending  $rank -> $dest = $lastVal")
        MPI.Isend(lastVal, dest, 0, comm)
        if rank > 0
            MPI.Recv!(recvVal, src, 0, comm)
         #   println("$rank: Received, $src -> $rank = $recvVal")
            sorted[1] = recvVal[end] <= array[1] && sorted[1]
        end
    end
    MPI.Allreduce!(sorted,MPI.LAND,comm)
    return sorted[1]
    end
end
    
    
    

# CHECKING ISSORTED nonscalable
# if arr uniform
# arrGlobal <- MPI.Allgather(array,comm)
# Base.issortedarrayglobal)
# else
# sizes <- MPI.Allgather(length(arr))
# arrGlobal <- MPI.Allgather()
