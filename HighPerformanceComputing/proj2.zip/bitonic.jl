
module Bitonic
export sort

using MPI

const DEBUG = true

function bitonic_split!(comm::MPI.Comm, rank::Int64, array::Vector{T}, work::Vector{T}, k::Int64, forward::Bool)::Nothing where T
    # comm: MPI Communicator
    # rank: [0, p) MPI rank on comm
    # array: distributed, holds the values belonging to this rank
    # work: space for receiving the message
    # k: a power of 2, k == 2^l, l is the "dimension" for this round of hypercube
    #    routing exchange. partner = (rank XOR k) will be the communicating partner
    # forward == true => the bitonic split should send the max values to the higher index of (rank, partner)
    #                     "     "      "      "     "   "  min values to the lower index of (rank, partner)
    # forward == false => the bitonic split should send the min values to the higher index of (rank, partner)
    #                      "     "      "      "     "   "  max values to the lower index of (rank, partner)
    #
    # Instructions:
    #
    # receive the message in work, overwrite the results in array
    #
    # Use point-to-point communication to implement the exchange.  Reread the
    # MPI slides: be careful to avoid deadlock!  Use non-blocking communication

    ### YOUR IMPLEMENTATION HERE (Instructor solution: 11 lines of code)
    
    #Exchange data from other processor
    #println("Split:Rank: $rank, K: $k: val ", xor(rank, k))   
    MPI.Isend(array, xor(rank, k), k, comm)    
    MPI.Recv!(work, xor(rank, k), k, comm)
    #Keep the smallest size(array) elements if forward, else keep the largest size(array) elements
    #Merge elements
    
    smaller = rank < xor(rank, k)
    tmp = Vector{T}(undef, 2*length(array))
    i=j=1
      while i <= length(array) && j <= length(work)
       if array[i] <= work[j]
            tmp[i+j-1] = array[i]
            i+=1
        else
            tmp[i+j-1] = work[j]
            j+=1
    end
    end
    while i <=length(array)
        tmp[i+j-1] = array[i]
        i+=1
    end
    while j <= length(work)
       tmp[i+j-1] = work[j]
        j+=1
    end
        
#     #Work now has all larger values
    if forward
        #Keep work instead of array
        array[:] = (rank < xor(rank, k)) ? tmp[1:length(array)] : tmp[length(array)+1:end] 
    else
        array[:] = (rank < xor(rank, k)) ? tmp[length(array)+1:end] : tmp[1:length(array)]
    end
    
    #This might be slowing things down
   # array[:] = (rank < xor(rank, k)) ? partialsort(vcat(array, work), 1:length(array), rev=!forward) : partialsort(vcat(array, work), 1:length(array), rev=forward)
    
    
    
    
    
    #println("\n$rank: keeping $array, k, $k, forward $forward")
        
        
        
        
# OVERWRITE RESULTS IN THE ARRAY


    return nothing
end

function bitonic_merge!(comm::MPI.Comm, rank::Int64, array::Vector{T}, work::Vector{T}, k::Int64, forward::Bool)::Nothing where T
    # comm: MPI Communicator
    # rank: [0, p) MPI rank on comm
    # array: distributed, holds the values belonging to this rank.
    #        INVARIANT: the distributed array is bitonic (over groups of k processors) on input
    # work: space for receiving the message
    # k: a power of 2, k == 2^l, l is the "dimension" for this round of hypercube
    #    routing exchange.  You want this to count down in your recursion: p, p/2,
    #    p/4, ..., 1.  The base case is k == 1 (no communication, just sort
    #    locally [lookup Base.sort! in the julia documentation])
    # forward: the sorting direction
    #          (true => sort ascending;
    #          false => sort descending)
    #
    # Instructions:
    #
    # - Handle the base case k == 1 (sort locally in the correct direction)
    # - call bitonic_split! this updates the invariant: the distributed array
    #      is now bitonic over groups of k/2 processors
    # - recursively call bitonic_merge! for k = div(k,2)
    #
    # You shouldn't call MPI routines directly in this function: all of the communication is in bitonic_split!

    ### YOUR IMPLEMENTATION HERE (Instructor solution: 6 lines of code)
    #println("Merge: Rank: $rank, K: $k, forward: $forward")
    if k == 1
        Base.sort!(array)
    else
       # println("Merge: Rank $rank, array $array, K:$k, forward: $forward")
        bitonic_split!(comm, rank, array, work, div(k,2), forward)
        bitonic_merge!(comm, rank, array, work, div(k,2), forward)

    end
    return nothing
end

function bitonic_sort!(comm::MPI.Comm, rank::Int64, array::Vector{T}, work::Vector{T}, k::Int64, forward::Bool)::Nothing where T
    # comm: MPI Communicator
    # rank: [0, p) MPI rank on comm
    # array: distributed, holds the values belonging to this rank.  No invariant! the input array is not bitonic or sorted
    # work: space for receiving the message
    # k: a power of 2, k == 2^l, see above
    # forward: the sorting direction
    #          (true => sort ascending;
    #          false => sort descending)
    #
    # Instructions:
    #
    # - Handle the base case k == 1 (sort locally in the correct direction)
    # - call bitonic_sort! recursively.  To make the result bitonic, you will
    #      have to determine based on `rank` and `k` how to switch the sorting
    #      direction
    # - the array is now bitonic, call bitonic_merge! for k

    ### YOUR IMPLEMENTATION HERE (Instructor solution: 10 lines of code)
    #println("Sort called: $rank, k: $k, forward: $forward")
    if k==1
        #Local communication. 
        Base.sort!(array)
    else
            #Forward is false when the l+1th bit is set to 1
        sort_forward = rank & k == 0
        #println("Sort: Rank: $rank, k: $k, sort_forward: $sort_forward")
        bitonic_sort!(comm, rank, array, work, div(k,2), sort_forward )  #Forward may need to be calculated diff for this?
     #  println("Sort(Pre-Merge): Rank $rank, array $array, K:$k")
        bitonic_merge!(comm, rank, array, work, k, sort_forward)   
      
        #println("Sort(Post_Merge): Rank $rank, array $array, K:$k")
    end
    return nothing
end

function sort(comm::MPI.Comm, array::Vector{T})::Vector{T} where T
    p = MPI.Comm_size(comm)
    rank = MPI.Comm_rank(comm)
    if DEBUG
        if p != nextpow(2, p)
            if rank == 0
                println("Bitonic sort requires a number of processors equal to a power of 2. $size is not a power of 2")
                @assert p == nextpow(2, p)
            end
        end

        n_local = length(array)
        n_local_max = MPI.Allreduce(n_local, MPI.MAX, comm)
        n_local_min = MPI.Allreduce(n_local, MPI.MIN, comm)
        if (n_local_max != n_local_min)
            if rank == 0
                println("Bitonic sort requires the same number of elements on each processor. min $n_local_min != $n_local_max")
                @assert n_local_max == n_local_min
            end
        end
    end

    out = copy(array)
    work = similar(out)
    bitonic_sort!(comm, rank, out, work, p, true)
    return out
end

end


#nonscalable bitonic sort stand in
# arrayGlobal
# Base.sort!(arrayglobal)
# sorted: arrayglobal[(rank-1)*m+rank*m]
