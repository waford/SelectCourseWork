
include("check.jl")
include("bitonic.jl")
include("sample.jl")
using .Check
using .Bitonic
using .Sample
using MPI
using Plots

MPI.Init()

comm = MPI.COMM_WORLD

n = 100

a = rand(n)
rank = MPI.Comm_rank(comm)



#println("$a rank: $rank" )

# if rank == 0
#     a = [0.91, 0.98]
# elseif rank == 1
#     a = [.24,.26]
# elseif rank == 2
#     a = [.56, .67]
# else
#     a = [.88, 38]
# end
#println("Rank $rank, $a")
b = Bitonic.sort(comm, a)
sorted = Check.issorted(comm, b)
if MPI.Comm_rank(comm) == 0
    println("Bitonic sort works: $sorted")
end

c = Sample.sort(comm, a)

sorted = Check.issorted(comm, c)

if MPI.Comm_rank(comm) == 0
    println("Sample sort works: $sorted")
end

## YOUR ADDITIONAL MEASUREMENTS HERE

##Test increasing array size
function is_root()
   return MPI.Comm_rank(comm) == 0
end


if is_root()
   size = MPI.Comm_size(comm)
    println("Using $size processors")
end

sizes = [2 .^ i for i in 7:24] #2^4-2^20
if is_root()
   println(sizes)

end

bitonic_sort_t = []
sample_sort_t = []
base_sort_t = []
sam_dist = []
bit_dist = []
bit_rev = []
sam_rev = []

for size = sizes
    list = rand(size)
    sample_list = copy(list)
    if is_root()
       # println("Starting test with size ", length(list))
    end
     #Syncronize all the processors
    MPI.Barrier(comm)
    t1 = MPI.Wtime()
    bit_sort_list = Bitonic.sort(comm, list)
    t2 = MPI.Wtime()
    t_bitonic = t2-t1

     MPI.Barrier(comm)
    t1 = MPI.Wtime()
    bit_sort_list = Bitonic.sort(comm, bit_sort_list)
    t2 = MPI.Wtime()
    t_bitonic_sorted = t2-t1

    #Test reverse sorted list
    Base.sort!(bit_sort_list, rev=true)
    MPI.Barrier(comm)
    t1 = MPI.Wtime()
    Bitonic.sort(comm, bit_sort_list)
    t2 = MPI.Wtime()
    t_bit_rev_sorted = t2-t1

     MPI.Barrier(comm)
    t1 = MPI.Wtime()
    samp_sort_list = Sample.sort(comm, sample_list)
    t2 = MPI.Wtime()
    t_sample = t2-t1
    #t_avg = MPI.Reduce(t, +, 0, comm)
    if is_root()

        #Measure for base case. N is Base.size times larger
        base_list = rand(size*MPI.Comm_size(comm))
        t1 = MPI.Wtime()
        Base.sort!(base_list)
        t2 = MPI.Wtime()
        push!(bitonic_sort_t, t_bitonic)
        push!(sample_sort_t, t_sample)
        push!(sam_dist, t_sample_sorted)
        push!(bit_dist, t_bitonic_sorted)
        push!(bit_rev, t_bit_rev_sorted)
        push!(sam_rev, t_sam_rev_sorted)
        push!(base_sort_t, t2-t1)

    end
end

#Test how the sorts do agains uniform vs non-uniform

bit_dist = []
sam_dist = []
bit_dist_sort = []
sam_dist_sort = []

for n = sizes
    #Measure performance on already sorted arrays

    list = rand(n*MPI.Comm_size(comm))


    bottom_ind = (MPI.Comm_rank(comm) * n) + 1
    top_ind = (MPI.Comm_rank(comm)+1) * n

    bit_list = copy(list[bottom_ind:top_ind])
    sam_list = copy(bit_list)

    MPI.Barrier(comm)
    t1 = MPI.Wtime()
    bit_sort_list = Bitonic.sort(comm, bit_list)
    t2 = MPI.Wtime()
    t_bitonic = t2-t1

    MPI.Barrier(comm)
    t1 = MPI.Wtime()
    samp_sort_list = Sample.sort(comm, sam_list)
    t2 = MPI.Wtime()
    t_sample = t2-t1

    #Sort array and do again
    list = Base.sort(list)

    tosort = list[bottom_ind:top_ind]
    tosort_sam = copy(tosort)
    MPI.Barrier(comm)
    t1 = MPI.Wtime()
    Bitonic.sort(comm, tosort)
    t2 = MPI.Wtime()

    t_bit = t2-t1

    MPI.Barrier(comm)
    t1 = MPI.Wtime()
    Sample.sort(comm, tosort_sam)
    t2 = MPI.Wtime()
    t_sam = t2-t1


    if is_root()
            push!(bit_dist, t_bitonic)
            push!(sam_dist, t_sample)
            push!(bit_dist_sort, t_bit)
            push!(sam_dist_sort, t_sam)
    end

end
if is_root()
    println(bitonic_sort_t,"\n\n" , sample_sort_t,"\n\n" , base_sort_t)
end






if is_root()
    plt = plot(sizes, [bitonic_sort_t, sample_sort_t, base_sort_t], labels=["Bitonic Sort" "Sample Sort" "Base"])
    pltl = plot(sizes, [bitonic_sort_t, sample_sort_t, base_sort_t],  labels=["Bitonic Sort" "Sample Sort" "Base"], yaxis=:log)
     png(plt, "./Bitonic_Sort")
     png(pltl, "./Bitonic_Sort_log")
   #    png(plt, "Bitonic_Sort")
   # png(pltl, "Bitonic_Sort_log")
    println("Done!")
end
## Testing Varying levels of randomness
a = 100
fullRand = rand(a)
frontSort = [Base.sort!(rand(div(a,2)));rand(div(a,2))]
midSort = [rand(div(a,4));Base.sort!(rand(div(a,2)));rand(div(a,4))]
endSort = [rand(div(a,2));Base.sort!(rand(div(a,2)))]
fullSort = Base.sort!(rand(a))
totArr = [fullRand, frontSort, midSort, endSort, fullSort]

bitonic_sort_t = []
sample_sort_t = []
base_sort_t = []

for i = 1:5

    #fullRand data
    MPI.Barrier(comm)
    t1 = MPI.Wtime()
    Bitonic.sort(comm, totArr[i])
    t2 = MPI.Wtime()
    t_bitonic = t2-t1
    MPI.Barrier(comm)
    t1 = MPI.Wtime()
    Sample.sort(comm, totArr[i])
    t2 = MPI.Wtime()
    t_sample = t2-t1

    if is_root()
        #Measure for base case. N is Base.size times larger
        t1 = MPI.Wtime()
        Base.sort!(totArr[i])
        t2 = MPI.Wtime()
        push!(bitonic_sort_t, t_bitonic)
        push!(sample_sort_t, t_sample)
        push!(base_sort_t, t2-t1)
    end

end
if is_root()
    net_sizes = sizes .* MPI.Comm_size(comm)
    bit_ksps = net_sizes ./ bitonic_sort_t
    samp_ksps = net_sizes ./ sample_sort_t
    base_ksps = net_sizes ./ base_sort_t


    plt_size = plot(net_sizes, [bitonic_sort_t, sample_sort_t, base_sort_t],  labels=["Bitonic Sort" "Sample Sort" "Base"],
            title="Time vs Array Size",
            xlabel = "Number of Elements",
            ylabel= "Time to sort (s)",
            legend=:topleft)
         plt_size_l = plot(net_sizes, [bitonic_sort_t, sample_sort_t, base_sort_t],  labels=["Bitonic Sort" "Sample Sort" "Base"],
            yaxis=:log,
            title="Time vs Array Size",
            xlabel = "Number of Elements",
            ylabel= "Time to sort (s)",
            legend=:bottomright)
        plt_size_ll = plot(net_sizes, [bitonic_sort_t, sample_sort_t, base_sort_t],  labels=["Bitonic Sort" "Sample Sort" "Base"],
            yaxis=:log,
            xaxis=:log,
            title="Time vs Array Size",
            xlabel = "Number of Elements",
            ylabel= "Time to sort (s)",
            legend=:topleft)
        plt_size_ksps = plot(net_sizes, [bit_ksps, samp_ksps, base_ksps],  labels=["Bitonic Sort" "Sample Sort" "Base"],
            xaxis=:log,
            yaxis=:log,
            title="Keys Sorted per Second vs Array Size",
            xlabel = "Number of Elements",
            ylabel= "Keys Sorted per Second",
            legend=:topleft)


    plt_sorted = plot(net_sizes, [bit_dist, sam_dist], labels=["Bitonic Sort" "Sample Sort"],
        title = "Sorted Arrays",
        xlabel = "Array size",
        ylabel = "Time to sort (s)",
            legend=:topright)

       plt_sorted_bit = plot(net_sizes, [bit_dist, bit_dist_sort],
        labels=["Random" "Sorted"],
        title = "Sorted vs Random Arrays Bitonic Sort",
        xlabel = "Array size",
        ylabel = "Time to sort (s)",
            legend=:topleft)


       plt_sorted_sam = plot(net_sizes, [sam_dist, sam_dist_sort],
        labels=["Random" "Sorted"],
        title = "Sorted vs Random Arrays Sample Sort",
        xlabel = "Array size",
        ylabel = "Time to sort (s)",
            legend=:topleft)





     savefig(plt_size, "./plots/Bitonic_Sort_size.png")
     savefig(plt_size_l, "./plots/Bitonic_Sort_size_log.png")
     savefig(plt_size_ll, "./plots/Bitonic_Sort_size_log_log.png")
     savefig(plt_sorted, "./plots/Bitonic_Sorted.png")
    savefig(plt_size_ksps, "./plots/Bitonic_Sort_ksps.png")
     savefig(plt_sorted_sam, "./plots/Sample_Sort_dist.png")
         savefig(plt_sorted_bit, "./plots/Bitonic_Sort_dist.png")

randArr = [0, 1, 2, 3, 4]

if is_root()
    plt = plot(randArr, [bitonic_sort_t, sample_sort_t, base_sort_t], labels=["Bitonic Sort" "Sample Sort" "Base"])
    pltl = plot(randArr, [bitonic_sort_t, sample_sort_t, base_sort_t],  labels=["Bitonic Sort" "Sample Sort" "Base"], yaxis=:log)
     png(plt, "./Rand_testing")
     png(pltl, "./Rand_testing_log")
   #    png(plt, "Bitonic_Sort")
   # png(pltl, "Bitonic_Sort_log")
    println("Done!")
end
